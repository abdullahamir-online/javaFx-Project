package com.company;



import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import jdk.nashorn.internal.runtime.ECMAException;
import javax.swing.*;


//most generalized student information
abstract class Student {
    String name;
    int regId;

    Student(String name, int regId) {
        this.name = name;
        this.regId = regId;
    }

    abstract void setSemesterFee(int semesterFeeOfRelatedProgram);
}



//specialized informaiton about student
class BBAStudents extends Student {
    String program;
    static int programDuration;
    static int semesterFeeOfRelatedProg;

    BBAStudents(String name, int regId, String program) {
        super(name, regId);
        this.program = program;
        System.out.println("Student 've been registered ! ");
    }

    void setSemesterFee(int semesterFeeOfRelatedProg) {
        BBAStudents.semesterFeeOfRelatedProg = semesterFeeOfRelatedProg;
    }
}



//specialized informaiton about student
class BEStudents extends Student {
    String program;
    static int programDuration;
    static int semesterFeeOfRelatedProg;

    BEStudents(String name, int regId, String program) {
        super(name, regId);
        this.program = program;
        System.out.println("Student 've been registered ! ");
    }

    void setSemesterFee(int semesterFeeOfRelatedProg) {
        BEStudents.semesterFeeOfRelatedProg = semesterFeeOfRelatedProg;
    }
}


//creating the main structrure of the application or Menu and integrate it with the backend logics
//it contain the multiple scene to approach towords the different modules
public class MenuScene extends Application {

    static int dataLength;
    static int organizationalControlCaller = MenuScene.organizationalControl();
    static ObservableList<Student> students = FXCollections.observableArrayList();

    private Scene menuScene;
    private Scene searchOptionScene;
    private Scene seeAllStudentsScene;
    private Label searchResultLabel = new Label("");

    @Override
    public void start(Stage stage) {
        VBox menuBox = createMenuBox(stage);
        VBox searchBox = createSearchOptionMenu(stage);
        searchOptionScene = new Scene(searchBox, 550, 400);

        VBox seeAllStudentsBox = createSeeAllStudentsMenu(stage);
        seeAllStudentsScene = new Scene(seeAllStudentsBox, 550, 400);

        stage.setScene(menuScene);
        stage.setTitle("Welcome To UniManage");
        stage.show();
    }

    private VBox createMenuBox(Stage stage) {
        VBox menuBox = new VBox();
        menuBox.setSpacing(10);
        menuBox.setStyle("-fx-background-color: #f0f0f0; -fx-padding: 15px;");

        Label titleLabel = new Label("UniManage");
        titleLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");
        menuBox.getChildren().add(titleLabel);

        String enrollIconUrl = "https://path/to/enroll/icon.png";
        String searchIconUrl = "https://path/to/search/icon.png";
        String seeAllIconUrl = "https://path/to/seeall/icon.png";
        String exitIconUrl = "https://path/to/exit/icon.png";

        HBox enrollItem = createMenuItem("Enroll", enrollIconUrl, (event) -> showRegistrationForm(stage));
        HBox searchItem = createMenuItem("Search", searchIconUrl, (event) -> stage.setScene(searchOptionScene));
        HBox seeAllItem = createMenuItem("See All", seeAllIconUrl, (event) -> showAllStudentsData(stage));
        HBox exitItem = createMenuItem("Exit", exitIconUrl, (event) -> stage.close());

        menuBox.getChildren().addAll(enrollItem, searchItem, seeAllItem, exitItem);

        menuScene = new Scene(menuBox, 550, 400 );

        return menuBox;
    }

    private HBox createMenuItem(String text, String iconUrl, EventHandler<MouseEvent> eventHandler) {
        ImageView icon = new ImageView();

        try {
            Image image = new Image(iconUrl);
            icon.setImage(image);
        } catch (Exception e) {
            System.err.println("Error loading icon: " + iconUrl);
        }

        Label label = new Label(text);
        HBox item = new HBox(icon, label);
        item.setStyle("-fx-background-color: #fff; -fx-padding: 10px;");
        item.setCursor(Cursor.HAND);
        item.setOnMouseClicked(eventHandler);
        return item;
    }

    VBox createSearchOptionMenu(Stage primaryStage) {
        Label titleLabel = new Label("Search Engine");
        titleLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");

        TextField idTextField = new TextField();
        idTextField.setPromptText("Enter student ID");

        Button searchButton = new Button("Search");
        Button deleteBtn = new Button("Delete Enrollment");
        deleteBtn.setVisible(false);
        searchButton.setOnAction(event -> {
            int stId;
            stId = 0 ;
            String searchingID = idTextField.getText().trim();
            if (!searchingID.isEmpty()) {
                try {
                    stId = Integer.parseInt(searchingID);

                    //   search logic here...
                    String searchResult = getSearchResults(stId);

                    if (searchResult != null) {
                        // Display search results in the label
                        searchResultLabel.setText("Search Results:\n" + searchResult); // Set the actual result string
                        deleteBtn.setVisible(true);
                    } else {
                        searchResultLabel.setText("Match not found");
                    }
                } catch (NumberFormatException e) {
                    searchResultLabel.setText("Invalid ID format. Please enter a valid ID formate (Num)");
                    showAlert("Invalid ID format","Please Enter a valid ID formate(Num)","");
                }
            } else {
                searchResultLabel.setText("Searching Field Can't be Empty");
            }


            int finalStId = stId;





        });

        Button clearButton = new Button("Clear");
        clearButton.setOnAction(event ->{
            idTextField.clear();
            searchResultLabel.setText("");


        });

        Button backButton = new Button("Back");
        backButton.setOnAction(event -> primaryStage.setScene(menuScene));







        deleteBtn.setOnAction(EventHandler -> {

            deleteBtn.managedProperty().bind(deleteBtn.visibleProperty());
            String searchingID = idTextField.getText().trim();
            if(searchingID.isEmpty()){
                showAlert("Please Search an ID First","Please Search a Registered  ID First","");
                return;

            }
            if(isValidStudentID(searchingID)){
                int stId = Integer.parseInt(searchingID);
                //sending deleting requst by calling the method
                deletingRequest(stId);
                idTextField.clear();
                searchResultLabel.setText("");
                deleteBtn.setVisible(false);
            } else {
                showAlert("Wrong ID Formate","Please Enter Valid ID Formate (Num)","");
                deleteBtn.setVisible(false);
            }



        });


        idTextField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue.isEmpty() || !newValue.equals(oldValue)) {
                deleteBtn.setVisible(false);
            } else {
                deleteBtn.setVisible(true);
            }
        });




        VBox resultBox = new VBox(searchResultLabel); // Container for the result label
        resultBox.setStyle("-fx-border-color: black; -fx-background-color: white; -fx-padding: 10px;");

        VBox searchBox = new VBox(10);
        searchBox.setPadding(new Insets(20, 20, 20, 20));
        searchBox.getChildren().addAll(titleLabel, idTextField, searchButton, clearButton, resultBox, deleteBtn,backButton);







        return searchBox;
    }


    private boolean chackIfAlraeadyExitst(int studentIdToCheck) {

        boolean isAlreadyExists = false ;
        for (Student student : students) {
            if (student.regId == studentIdToCheck) {
                isAlreadyExists = true ;
                break;
            }
        }



        if(isAlreadyExists){
            return true ;
        }
        else {
            return false;
        }
    }






    private String getSearchResults(int studentId) {

        String result = null;
        for (Student student : students) {
            if (student.regId == studentId) {
                result = "Student ID: " + student.regId + "\nName: " + student.name + "\nDepartment: " + getDepartment(student);
                break;

            }
        }
        return result;
    }

    //deleting request method implementation
    private void deletingRequest(int studentIdToDelete) {
        boolean isDeleted  = false ;
        for (Student student : students) {
            if (student.regId == studentIdToDelete) {
                students.remove(student);
                isDeleted = true ;
                break;
            }
        }
        if(isDeleted){
            showAlert("Enrollment Deleted","Enrolled Student at this ID : "+studentIdToDelete+ " has been Deleted ! ","");
        }
        else {
            showAlert("Not Available","No Entered ID availbale To Delete","");
        }
    }


    private String getDepartment(Student student) {
        if (student instanceof BBAStudents) {
            return ((BBAStudents) student).program;
        } else if (student instanceof BEStudents) {
            return ((BEStudents) student).program;
        }
        return "";
    }





    private VBox createSeeAllStudentsMenu(Stage primaryStage) {
        Label titleLabel = new Label("All Students Data");
        titleLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");

        Button backButton = new Button("Back");

        VBox seeAllStudentsBox = new VBox(10);
        seeAllStudentsBox.setPadding(new Insets(20, 20, 20, 20));
        seeAllStudentsBox.getChildren().addAll(titleLabel, backButton);

        backButton.setOnAction(event -> primaryStage.setScene(menuScene));
        return seeAllStudentsBox;
    }



    private void showAllStudentsData(Stage primaryStage) {
        ObservableList<String> allStudentsData = getAllStudentsData();

        if (allStudentsData.isEmpty()) {
            Label noDataLabel = new Label("No data available. Please enter data first.");
            noDataLabel.setStyle("-fx-border-color: black; -fx-background-color: white; -fx-padding: 10px;");

            Button backButton = new Button("Back");
            backButton.setOnAction(event -> primaryStage.setScene(menuScene));

            VBox seeAllStudentsBox = new VBox(10);
            seeAllStudentsBox.setPadding(new Insets(20, 20, 20, 20));
            seeAllStudentsBox.getChildren().addAll(noDataLabel, backButton);



            seeAllStudentsScene.setRoot(seeAllStudentsBox);
        }

        else {
            Label allStudentsLabel = new Label();
            allStudentsLabel.setText("All Students Data:\n" + String.join("\n", allStudentsData));
            allStudentsLabel.setStyle("-fx-border-color: black; -fx-background-color: white; -fx-padding: 10px;");

            Button backButton = new Button("Back");
            backButton.setOnAction(event -> primaryStage.setScene(menuScene));

            VBox seeAllStudentsBox = new VBox(10);
            seeAllStudentsBox.setPadding(new Insets(20, 20, 20, 20));
            seeAllStudentsBox.getChildren().addAll(allStudentsLabel, backButton);

            seeAllStudentsScene.setRoot(seeAllStudentsBox);
        }

        primaryStage.setScene(seeAllStudentsScene);
    }





    private ObservableList<String> getAllStudentsData() {
        ObservableList<String> allStudentsData = FXCollections.observableArrayList();
        for (Student student : students) {
            allStudentsData.add("Student ID: " + student.regId + " | Name: " + student.name + " | Department: " + getDepartment(student));
        }
        return allStudentsData;
    }






    private void showRegistrationForm(Stage primaryStage) {
        Label labelReg = new Label("Student Registration : ");
        labelReg.setStyle("-fx-font-size: 24px; -fx-font-weight: bold");
        Label nameLabel = new Label("Student Name:");
        nameLabel.setStyle("-fx-font-size: 12px; -fx-font-weight: bold");
        TextField nameTextField = new TextField();

        Label idLabel = new Label("Student ID:");
        idLabel.setStyle("-fx-font-size: 12px; -fx-font-weight: bold");
        TextField idTextField = new TextField();



        Label departLabel = new Label("Department:");
        departLabel.setStyle("-fx-font-size: 12px; -fx-font-weight: bold");
        ComboBox<String> departComboBox = new ComboBox<>();
        departComboBox.getItems().addAll("BBA", "BE");
        departComboBox.setPromptText("Select Department");

        Button registerButton = new Button("Register");
        Button clearButton = new Button("Clear");

        clearButton.setOnAction(event -> {
            nameTextField.clear();
            idTextField.clear();
            departComboBox.getSelectionModel().clearSelection();
        });
        registerButton.setOnAction(event -> {

            String studentName = nameTextField.getText();
            String studentID = idTextField.getText();
            int studentId;
            String selectedDepartment = departComboBox.getValue();






            if (!(studentName.isEmpty()) && !(studentID.isEmpty()) && !(selectedDepartment == null)) {

                studentName = studentName.trim();


                if (!isValidAlphaName(studentName)) {
                    showAlert("Invalid Name", "Name should contain only alphabetical characters.", "");
                    return;
                }
                else if(studentName.length()>25){
                    showAlert("Invalid Characters Length", "Characters Length should be Under 25","");
                    return;
                }


                if(!isValidStudentID(studentID)){
                    showAlert("Invalid ID","ID should contain only Number formate ", "");
                    return;
                }
                else if(studentID.length()>15){
                    showAlert("Invalid ID Lenght","ID Length should be under the 15 Digits ","");
                    return;
                }

                else{
                    studentId = Integer.parseInt(studentID);
                    if( chackIfAlraeadyExitst(studentId)){
                        showAlert("Already Registered!","Registration has already been taken at this ID","");
                        return;
                    }
                }



                if (selectedDepartment.equalsIgnoreCase("BBA")) {
                    students.add(new BBAStudents(studentName, studentId, selectedDepartment));
                } else if (selectedDepartment.equalsIgnoreCase("BE")) {
                    students.add(new BEStudents(studentName, studentId, selectedDepartment));
                }



                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Successfully Registered!");
                alert.setHeaderText("Registration has been taken");
                alert.setContentText("Successfully Registered!");

                ButtonType backButton = new ButtonType("Back", ButtonBar.ButtonData.CANCEL_CLOSE);
                alert.getButtonTypes().add(backButton);

                alert.setOnCloseRequest(closeEvent -> {
                    if (alert.getResult() == backButton) {
                        primaryStage.setScene(menuScene);
                    }
                });

                alert.showAndWait();
            } else {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Registration Failed Due to Empty Fields");
                alert.setHeaderText("Try to Attempt Empty Registration");
                alert.setContentText("Fields can't be Empty");

                ButtonType backButton = new ButtonType("Back", ButtonBar.ButtonData.CANCEL_CLOSE);
                alert.getButtonTypes().add(backButton);

                alert.setOnCloseRequest(closeEvent -> {
                    if (alert.getResult() == backButton) {
                        primaryStage.setScene(menuScene);
                    }
                });

                alert.showAndWait();
            }
        });

        Button backButton = new Button("Back");
        backButton.setOnAction(event -> primaryStage.setScene(menuScene));

        VBox registrationForm = new VBox(10);
        registrationForm.setPadding(new Insets(20, 20, 20, 20));
        registrationForm.getChildren().addAll(labelReg,nameLabel, nameTextField, idLabel, idTextField, departLabel, departComboBox, registerButton, clearButton,backButton);

        Scene registrationScene = new Scene(registrationForm, 550, 400);

        primaryStage.setScene(registrationScene);
    }



    //showing alert Method implementation:
    private void showAlert(String title, String headerText, String contentText) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.setContentText(contentText);

        ButtonType backButton = new ButtonType("Back", ButtonBar.ButtonData.CANCEL_CLOSE);
        alert.getButtonTypes().add(backButton);

        alert.showAndWait();
    }



    private boolean isValidAlphaName(String studentName) {
        return studentName.matches("\\s*[a-zA-Z]+(\\s+[a-zA-Z]+)*\\s*");
    }

    //checking the id
    private boolean isValidStudentID(String studentID) {
        return (studentID.matches("[1-9]\\d*")  );
    }

    //pre organizationalControl
    private static int organizationalControl() {
        BBAStudents.semesterFeeOfRelatedProg = 100000;
        BEStudents.semesterFeeOfRelatedProg = 90000;
        MenuScene.dataLength = 1000;
        BEStudents.programDuration = 4;
        BBAStudents.programDuration = 5;
        return 0;
    }



    //launching the application
    public static void main(String[] args) {
        launch(args);

    }




}





